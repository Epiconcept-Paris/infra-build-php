# POSIX regex functions

## Warning

This extension is deprecated and unmaintained.

## Description

This extension provides the ereg family of functions that were provided with
PHP 3-5. These functions have been superseded by the preg family of functions
provided by the PCRE extension: http://php.net/pcre

Although it should be possible to build this extension with PHP 7.0, you are
strongly encouraged to port your code to use PCRE, as this extension is not
maintained and is available for historical reasons only.
